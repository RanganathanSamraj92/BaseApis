var welcome = require('./welcome.js');
var users = require('./users.js');
var calculate = require('./calculate.js');
var companies = require('./companies.js');
var getAllCompanies = require('./getAllCompanies.js');
