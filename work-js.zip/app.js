var express = require('express');
var router = express.Router()
var app = express();
const port = 3000
var server = app.listen(port, function() {
     console.log(`Example app listening on port ${port}!`);
});
app.use(function (req, res, next) {
  console.log('Time:', Date.now())
  next()
})

module.exports = app;
